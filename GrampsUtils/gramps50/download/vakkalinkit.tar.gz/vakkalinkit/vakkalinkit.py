#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2015-2016 Nick Hall
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, 
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

"""
    Tools/Database Processing/fetchsources - fetches data from digihakemisto and add source citations as notes.
    Use "generatecitations" after this to actually create the source citations, sources and archives.
"""
import configparser, os
from bs4 import BeautifulSoup
            
from gi.repository import Gtk, Gdk, GObject
#import gtk

from gramps.gui.plug import tool
from gramps.gui.utils import ProgressMeter, open_file_with_default_application
from gramps.gen.db import DbTxn
from gramps.gen.lib import Note
from gramps.gen.const import GRAMPS_LOCALE as glocale
try:
    _trans = glocale.get_addon_translator(__file__)
except ValueError:
    _trans = glocale.translation
_ = _trans.gettext

settings_file = 'fetchsources.ini'

#-------------------------------------------------------------------------
#
# Tool
#
#-------------------------------------------------------------------------
class Tool(tool.Tool):

    def __init__(self, dbstate, user, options_class, name, callback=None):
        self.user = user
        self.uistate = user.uistate
        self.dbstate = dbstate
        tool.Tool.__init__(self, dbstate, options_class, name)
        modname = os.path.abspath(__file__)
        dirname = os.path.dirname(modname)
        self.settings_file = os.path.join(dirname,__name__+".ini")
        
        self.config = configparser.ConfigParser(allow_no_value=True)
        self.config.read(self.settings_file)
        self.run()

    def run(self):
        from collections import defaultdict

        # from http://www.holmes4.com/wda/MyBooks/PythonGTK/PyGTK_Development-Dialogs.html#Message_Dialog_Figure
        dialog = Gtk.Dialog(title=_("Anna Vakka-osoite"), parent=None,
                            flags=Gtk.DialogFlags.MODAL)
        dialog.add_button("Ok", Gtk.ResponseType.OK)
        dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
        #dialog.add_button("Edit settings", Gtk.ResponseType.OK)
        dialog.set_default_response(Gtk.ResponseType.OK)
        lbl1 = Gtk.Label("URL:")
        url = Gtk.Entry()
        url.set_width_chars(50)
        self.only_places_checkbox = Gtk.CheckButton(_("Only places"))
        settings_button = Gtk.Button(_("Edit settings"))
        settings_button.connect("clicked",self.cb_edit_settings)
        grid = Gtk.Grid()
        grid.attach(lbl1, 0, 0, 1, 1)
        grid.attach(url, 1, 0, 1, 1)
        #grid.attach(self.only_places_checkbox, 1, 1, 1, 1)
        #grid.attach(settings_button, 0, 2, 1, 1)
        dialog.vbox.pack_start(grid, False, False, 5)
        dialog.show_all()
        result = dialog.run()
        if result == Gtk.ResponseType.OK:
            self.fetch(url.get_text())
        dialog.destroy()
        
    def cb_edit_settings(self, obj):
        open_file_with_default_application(self.settings_file, self.uistate)
        
    def fetch(self, dh_url):
        self.dofetch(dh_url)
        return
        try:
            self.dofetch(dh_url)
            pass
        except:
            dialog = Gtk.Dialog(title=_("Fetch FAILED"), parent=None,
                                flags=Gtk.DialogFlags.MODAL)
            lbl1 = Gtk.Label("Operation failed")
            dialog.vbox.pack_start(lbl1, False, False, 5)
            dialog.add_button("Ok", Gtk.ResponseType.OK)
            dialog.set_default_response(Gtk.ResponseType.OK)
            dialog.show_all()
            result = dialog.run()
            dialog.destroy()

    def dofetch(self, url):
#        url = "http://www.narc.fi:8080/VakkaWWW/Selaus.action?kuvailuTaso=SARJA&avain=302982.KA"

        import urllib
        import json
        from pprint import pprint
        import urllib.parse
        import time
        import xml.dom.minidom

        with urllib.request.urlopen(url) as urlstream:
            soup = BeautifulSoup(urlstream)

            with DbTxn(_("Add notes"), self.db) as trans:
                links = soup.find_all('a')
                num = 0
                for link in links:
                    href = link.get("href")
                    if not href: continue
                    if not href.startswith("Selaus.action"): continue
                    i = href.find("?")
                    if i < 0: continue
                    querystring = href[i+1:]
                    args = urllib.parse.parse_qs(querystring)
                    kuvailutaso = args['kuvailuTaso'][0]
                    if kuvailutaso != "AY": continue
                    avain = args['avain'][0]
                    notetext = "{avain}: {text}".format(avain=avain,text=link.text)
                    note = Note()
                    note.set(notetext)
                    note_handle = self.db.add_note(note, trans)
                    num += 1

        
        dialog = Gtk.Dialog(title=_("Fetch done"), parent=None,
                            flags=Gtk.DialogFlags.MODAL)
        lbl1 = Gtk.Label("Haettu {} viitettä".format(num))
        dialog.vbox.pack_start(lbl1, False, False, 5)
        dialog.add_button("Ok", Gtk.ResponseType.OK)
        dialog.set_default_response(Gtk.ResponseType.OK)
        dialog.show_all()
        result = dialog.run()
        dialog.destroy()
        
    def non_place(self,kommentti): 
        kommentti = kommentti.lower()
        for s in self.non_place_contains:
            if kommentti.find(s) >= 0: return True
        for s in self.non_place_exact:
            if kommentti == s: return True
        return False
                

#------------------------------------------------------------------------
#
# Options
#
#------------------------------------------------------------------------
class Options(tool.ToolOptions):
    """
    Define options and provides handling interface.
    """

    def __init__(self, name, person_id=None):
        tool.ToolOptions.__init__(self, name, person_id)

